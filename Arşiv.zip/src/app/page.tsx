"use client";
import Mascot from "@/components/Mascot";
import EventAnnouncement from "@/components/EventAnnouncement";
import Weather from "@/components/Weather";
import { useUnread } from "@/components/NotificationProvider";
import PushControl from "@/components/PushControl";
import StudentHome from "@/components/student/StudentHome";
import UnreadBadge from "@/components/UnreadBadge";
import { CATEGORIES, TONE_BG } from "@/lib/menuData";
import { useOpenCats } from "@/lib/useOpenCats";
import { useUser } from "@/lib/useUser";
import {
  faArrowRight,
  faChevronDown,
  faMessage,
  faHand,
  faMagnifyingGlass,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  AnimatePresence,
  motion,
  useMotionValue,
  useScroll,
  useSpring,
  useTransform,
} from "framer-motion";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";

const tiles = [
  {
    kind: "news",
    t: "Biga Gündemi",
    d: "Haberler ve duyurular",
    href: "/haberler",
    c: "bg-coral text-deep",
  },
  {
    kind: "business",
    t: "İşletmeler",
    d: "Fiyat, saat, tuvalet",
    href: "/isletmeler",
    c: "bg-tide text-deep",
  },
  {
    kind: "transport",
    t: "Ulaşım",
    d: "Otobüs ve servis",
    href: "/ulasim",
    c: "bg-sun text-deep",
  },
  {
    kind: "map",
    t: "Biga Haritası",
    d: "Şehri keşfet, yakınını bul",
    href: "/harita",
    c: "bg-sky text-deep",
  },
  {
    kind: "notes",
    t: "Notlar",
    d: "Ders notu, PDF",
    href: "/notlar",
    c: "bg-sea text-white",
  },
  {
    kind: "market",
    t: "Kitap pazarı",
    d: "İkinci el kitap",
    href: "/kitap-pazari",
    c: "bg-coral text-deep",
  },
  {
    kind: "jobs",
    t: "İş İlanları",
    d: "İş, staj ve iletişim bilgileri",
    href: "/is-ilanlari",
    c: "bg-tide text-deep",
  },
  {
    kind: "ustalar",
    t: "Usta Bul",
    d: "Tesisatçı, elektrikçi, mobilyacı",
    href: "/ustalar",
    c: "bg-sun text-deep",
  },
  {
    kind: "arkadaslar",
    t: "Arkadaşlar",
    d: "Arkadaş ekle, mesajlaş",
    href: "/arkadaslar",
    c: "bg-coral text-deep",
  },
  {
    kind: "friends",
    t: "Topluluk",
    d: "Gönderi, soru-cevap ve forum",
    href: "/topluluk",
    c: "bg-sky text-deep",
  },
  {
    kind: "magazine",
    t: "Dergi",
    d: "Okulun dergisi",
    href: "/dergi",
    c: "bg-tide text-deep",
  },
  {
    kind: "schedule",
    t: "Ders Programı",
    d: "Bölümüne göre haftalık çizelge",
    href: "/ders-programi",
    c: "bg-sky text-deep",
  },
  {
    kind: "pomodoro",
    t: "Pomodoro",
    d: "Odaklan, mola ver, hedefe ulaş",
    href: "/pomodoro",
    c: "bg-sun text-deep",
  },
  {
    kind: "bigocuk",
    t: "Bigocuk",
    d: "Oyna, anket doldur, Bigcoin kazan",
    href: "/bigocuk",
    c: "bg-sky text-deep",
  },
  {
    kind: "about",
    t: "Hakkımızda",
    d: "Misyon, ekip ve kulübümüz",
    href: "/hakkimizda",
    c: "bg-coral text-deep",
  },
  {
    kind: "ataturk",
    t: "Atatürk Köşesi",
    d: "Gençliğe Hitabe, Nutuk ve marşlar",
    href: "/ataturk",
    c: "bg-tide text-deep",
  },
  {
    kind: "kultur",
    t: "Kültür Ajandası",
    d: "Özel günler, tatiller, sınav takvimi",
    href: "/kultur",
    c: "bg-sky text-deep",
  },
  {
    kind: "yemekhane",
    t: "Yemekhane",
    d: "KYK yurtları ve Ağaköy menüsü",
    href: "/yemekhane",
    c: "bg-coral text-deep",
  },
  {
    kind: "ubys",
    t: "ÜBYS",
    d: "ÇOMÜ öğrenci bilgi sistemi",
    href: "https://ubys.comu.edu.tr/",
    c: "bg-sun text-deep",
    external: true,
  },
];
const words = ["Kafe", "Kırtasiye", "Eczane", "Çamaşırhane", "Market"];
const list = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08, delayChildren: 0.15 } },
};
const item = {
  hidden: { opacity: 0, y: 28, scale: 0.92 },
  show: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { type: "spring" as const, stiffness: 260, damping: 20 },
  },
};

function TileArt({ kind }: { kind: string }) {
  const shared = {
    className: `tile-art tile-art--${kind}`,
    viewBox: "0 0 112 84",
    "aria-hidden": true as const,
  };
  switch (kind) {
    case "business":
      return (
        <svg {...shared}>
          <path d="M25 35h62v39H25z" fill="currentColor" opacity=".14" />
          <path d="M20 35h72l-7-18H27z" fill="currentColor" opacity=".24" />
          <path
            d="M20 35h72l-7-18H27z"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinejoin="round"
          />
          <path
            d="M25 35v39h62V35M37 35v-5a8 8 0 0 1 16 0v5m11 0v-5a8 8 0 0 1 16 0v5"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
          />
          <path
            d="M34 46h17v14H34zm34 0h11v28H68z"
            fill="currentColor"
            opacity=".3"
            stroke="currentColor"
            strokeWidth="2"
          />
          <path
            d="M18 75h78"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
          />
        </svg>
      );
    case "transport":
      return (
        <svg {...shared}>
          <path
            d="M21 54V28q0-8 9-8h47q9 0 9 8v26"
            fill="currentColor"
            opacity=".2"
            stroke="currentColor"
            strokeWidth="3"
          />
          <path
            d="M24 30h59v25H24z"
            fill="currentColor"
            opacity=".13"
            stroke="currentColor"
            strokeWidth="3"
          />
          <path
            d="M29 34h16v13H29zm22 0h15v13H51zm21 0h7v13h-7z"
            fill="currentColor"
            opacity=".38"
          />
          <path d="M25 55h58v8H25z" fill="currentColor" opacity=".32" />
          <circle cx="36" cy="64" r="7" fill="currentColor" />
          <circle cx="73" cy="64" r="7" fill="currentColor" />
          <circle cx="36" cy="64" r="2.5" fill="rgb(var(--card))" />
          <circle cx="73" cy="64" r="2.5" fill="rgb(var(--card))" />
          <path
            d="M17 74h75"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
            strokeDasharray="5 7"
          />
        </svg>
      );
    case "map":
      return (
        <svg {...shared}>
          <path
            d="m18 30 25-11 25 11 26-11v43L68 73 43 62 18 73z"
            fill="currentColor"
            opacity=".15"
          />
          <path
            d="M43 19v43m25-32v43M18 30l25-11 25 11 26-11M18 73l25-11 25 11 26-11"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinejoin="round"
          />
          <path
            d="M56 31c-8 0-14 6-14 14 0 11 14 25 14 25s14-14 14-25c0-8-6-14-14-14Z"
            fill="rgb(var(--coral))"
            stroke="currentColor"
            strokeWidth="3"
          />
          <circle cx="56" cy="45" r="5" fill="rgb(var(--card))" />
        </svg>
      );
    case "notes":
      return (
        <svg {...shared}>
          <path
            d="M56 27c-12-9-25-10-39-6v43c14-4 27-3 39 6 12-9 25-10 39-6V21c-14-4-27-3-39 6z"
            fill="currentColor"
            opacity=".18"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinejoin="round"
          />
          <path
            d="M56 27v43M27 32c8-2 15-1 22 2m-22 8c8-2 15-1 22 2m36-12c-8-2-15-1-22 2m22 8c-8-2-15-1-22 2"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
          />
          <path
            d="m77 14 3 5 6 1-4 4 1 6-6-3-5 3 1-6-4-4 6-1z"
            fill="currentColor"
          />
        </svg>
      );
    case "market":
      return (
        <svg {...shared}>
          <path
            d="M25 24q0-5 5-5h43q5 0 5 5v49q0 5-5 5H30q-5 0-5-5z"
            fill="currentColor"
            opacity=".16"
            stroke="currentColor"
            strokeWidth="3"
          />
          <path
            d="M34 29h35v4H34zm0 11h27v3H34zm0 9h31v3H34z"
            fill="currentColor"
            opacity=".55"
          />
          <path
            d="M80 43h12v27a6 6 0 0 1-12 0z"
            fill="currentColor"
            opacity=".28"
            stroke="currentColor"
            strokeWidth="3"
          />
          <path
            d="M86 48v18m-5-9h10"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
          />
          <path
            d="M20 78h74"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
          />
        </svg>
      );
    case "jobs":
      return (
        <svg {...shared}>
          <path
            d="M22 34h68q5 0 5 5v33q0 5-5 5H22q-5 0-5-5V39q0-5 5-5z"
            fill="currentColor"
            opacity=".18"
            stroke="currentColor"
            strokeWidth="3"
          />
          <path
            d="M42 34v-7q0-5 5-5h18q5 0 5 5v7"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinejoin="round"
          />
          <path
            d="M17 54h78"
            stroke="currentColor"
            strokeWidth="3"
          />
          <path
            d="M50 49h12v11H50z"
            fill="currentColor"
            opacity=".55"
            stroke="currentColor"
            strokeWidth="2"
          />
        </svg>
      );
    case "news":
      return (
        <svg {...shared}>
          <path
            d="M24 24h50q5 0 5 5v44H30q-6 0-6-6z"
            fill="currentColor"
            opacity=".18"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinejoin="round"
          />
          <path
            d="M79 40h10q4 0 4 4v26q0 6-6 6H30"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinejoin="round"
          />
          <path d="M33 34h34v10H33z" fill="currentColor" opacity=".55" />
          <path
            d="M33 53h34M33 61h34M33 69h22"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
          />
          <path
            d="M88 18a14 14 0 0 1 10 10M84 25a8 8 0 0 1 6 6"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
          />
          <circle cx="82" cy="31" r="3" fill="currentColor" />
        </svg>
      );
    case "ustalar":
      return (
        <svg {...shared}>
          <path
            d="M30 70 66 34"
            fill="none"
            stroke="currentColor"
            strokeWidth="9"
            strokeLinecap="round"
            opacity=".28"
          />
          <path
            d="M30 70 66 34"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
          />
          <path
            d="M62 38a14 14 0 1 1 14-14l-7 3-6-6 3-7a14 14 0 0 0-10 24z"
            fill="currentColor"
            opacity=".3"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinejoin="round"
          />
          <path
            d="M84 76 52 44"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
          />
          <path
            d="m80 80 8-8 6 6-8 8z"
            fill="currentColor"
            opacity=".55"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinejoin="round"
          />
          <circle cx="24" cy="76" r="4" fill="currentColor" />
        </svg>
      );
    case "friends":
      return (
        <svg {...shared}>
          <path
            d="M15 69c1-13 9-20 20-20s19 7 20 20"
            fill="currentColor"
            opacity=".23"
            stroke="currentColor"
            strokeWidth="3"
          />
          <circle
            cx="35"
            cy="34"
            r="12"
            fill="currentColor"
            opacity=".28"
            stroke="currentColor"
            strokeWidth="3"
          />
          <path
            d="M56 71c1-12 8-19 18-19s18 7 19 19"
            fill="currentColor"
            opacity=".18"
            stroke="currentColor"
            strokeWidth="3"
          />
          <circle
            cx="74"
            cy="38"
            r="11"
            fill="currentColor"
            opacity=".25"
            stroke="currentColor"
            strokeWidth="3"
          />
          <path
            d="M45 17h31q6 0 6 6v8q0 6-6 6H63l-8 7v-7h-3q-7 0-7-6v-8q0-6 6-6z"
            fill="rgb(var(--card))"
            opacity=".7"
          />
          <path
            d="M56 27h20"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
          />
        </svg>
      );
    case "arkadaslar":
      return (
        <svg {...shared}>
          <path d="M14 70c1-12 8-19 18-19s17 7 18 19" fill="currentColor" opacity=".23" stroke="currentColor" strokeWidth="3" />
          <circle cx="32" cy="36" r="11" fill="currentColor" opacity=".28" stroke="currentColor" strokeWidth="3" />
          <path d="M58 71c1-12 8-19 18-19s17 7 18 19" fill="currentColor" opacity=".18" stroke="currentColor" strokeWidth="3" />
          <circle cx="76" cy="38" r="11" fill="currentColor" opacity=".25" stroke="currentColor" strokeWidth="3" />
          <path d="M54 30c-5-7-14-1-9 6l9 9 9-9c5-7-4-13-9-6z" fill="rgb(var(--card))" opacity=".8" />
        </svg>
      );
    case "schedule":
      return (
        <svg {...shared}>
          <rect
            x="22"
            y="18"
            width="68"
            height="54"
            rx="7"
            fill="currentColor"
            opacity=".16"
            stroke="currentColor"
            strokeWidth="3"
          />
          <path
            d="M22 33h68M39 14v10m34-10v10M36 44h10m9 0h10m9 0h10m-38 13h10m9 0h10"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
          />
          <path
            d="M40 73h32m-25 6h18"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
          />
        </svg>
      );
    case "pomodoro":
      return (
        <svg {...shared}>
          <circle cx="56" cy="48" r="26" fill="currentColor" opacity=".16" stroke="currentColor" strokeWidth="3" />
          <path d="M56 22c-1-6-6-10-12-10 1 5 5 9 12 10z" fill="currentColor" opacity=".7" />
          <path d="M56 22c2-6 8-9 14-8-2 5-7 8-14 8z" fill="currentColor" opacity=".7" />
          <g className="pomo-tile-hand">
            <path d="M56 48V33" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" />
          </g>
          <circle cx="56" cy="48" r="3.5" fill="currentColor" />
          <path d="M26 78q7-6 14 0t14 0 14 0 14 0" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" opacity=".55" />
          <path d="m96 20 2.5 6 6 2.5-6 2.5-2.5 6-2.5-6-6-2.5 6-2.5z" fill="currentColor" opacity=".7" />
        </svg>
      );
    case "bigocuk":
      return (
        <svg {...shared}>
          <circle cx="68" cy="38" r="27" fill="currentColor" opacity=".16" stroke="currentColor" strokeWidth="3" />
          <circle cx="68" cy="38" r="19" fill="none" stroke="currentColor" strokeWidth="2.5" opacity=".55" />
          <text x="68" y="48" textAnchor="middle" fontSize="28" fontWeight="800" fill="currentColor" fontFamily="'Baloo 2', sans-serif">B</text>
          <path d="M12 76Q30 62 46 72" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeDasharray="2 8" />
          <path d="m100 14 3 7 7 3-7 3-3 7-3-7-7-3 7-3z" fill="currentColor" opacity=".7" />
        </svg>
      );
    case "about":
      return (
        <svg {...shared}>
          <circle
            cx="56"
            cy="42"
            r="28"
            fill="currentColor"
            opacity=".14"
            stroke="currentColor"
            strokeWidth="3"
          />
          <path
            d="M42 45q1-14 14-14t14 14q0 7-7 12-4 3-4 8h-7q0-9 7-14 4-3 4-6a7 7 0 0 0-14 0zm10 24h8"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
          />
          <path
            d="m24 18 2 5 5 2-5 2-2 5-2-5-5-2 5-2zm64 39 2 5 5 2-5 2-2 5-2-5-5-2 5-2z"
            fill="currentColor"
          />
        </svg>
      );
    case "ataturk":
      return (
        <svg {...shared}>
          <image
            href="https://upload.wikimedia.org/wikipedia/commons/8/8e/Ataturk_imza_01_tam35blog.png"
            x="12"
            y="8"
            width="94"
            height="30"
            preserveAspectRatio="xMidYMid meet"
          />
        </svg>
      );
    case "kultur":
      return (
        <svg {...shared}>
          <path d="M20 30 56 14l36 16z" fill="currentColor" opacity=".24" stroke="currentColor" strokeWidth="3" strokeLinejoin="round" />
          <path d="M26 35h60" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
          <path d="M33 40v26M49 40v26M65 40v26M81 40v26" stroke="currentColor" strokeWidth="6" strokeLinecap="round" opacity=".35" />
          <path d="M22 72h68" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
        </svg>
      );
    case "yemekhane":
      return (
        <svg {...shared}>
          <g fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" opacity=".5">
            <path d="M40 30c-5-6 5-9 0-17" />
            <path d="M56 30c-5-6 5-9 0-17" />
            <path d="M72 30c-5-6 5-9 0-17" />
          </g>
          <path d="M16 38h80c0 20-16 34-40 34S16 58 16 38z" fill="currentColor" opacity=".24" stroke="currentColor" strokeWidth="3" strokeLinejoin="round" />
          <path d="M16 38h80" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
          <path d="M38 76h36" stroke="currentColor" strokeWidth="4" strokeLinecap="round" opacity=".4" />
        </svg>
      );
    case "ubys":
      return (
        <svg {...shared}>
          <rect
            x="20"
            y="20"
            width="72"
            height="48"
            rx="6"
            fill="currentColor"
            opacity=".15"
            stroke="currentColor"
            strokeWidth="3"
          />
          <path
            d="M37 79h38m-19-11v11M31 31h39M31 42h25M31 53h15"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
          />
          <path
            d="M72 48h14m-6-6 6 6-6 6"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      );
    default:
      return (
        <svg {...shared}>
          <path
            d="M25 18h52q7 0 7 7v47q0 6-7 6H25z"
            fill="currentColor"
            opacity=".17"
            stroke="currentColor"
            strokeWidth="3"
          />
          <path
            d="M25 18v60q-10-3-10-11V27q0-8 10-9z"
            fill="currentColor"
            opacity=".32"
            stroke="currentColor"
            strokeWidth="3"
          />
          <path
            d="M38 33h33M38 43h27M38 53h33M38 63h22"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
          />
          <path
            d="m88 14 2.5 6 6 2.5-6 2.5-2.5 6-2.5-6-6-2.5 6-2.5z"
            fill="currentColor"
          />
        </svg>
      );
  }
}

function Tile({ x, n }: { x: (typeof tiles)[number]; n: number }) {
  const ref = useRef<HTMLAnchorElement>(null);
  const rx = useSpring(useMotionValue(0), { stiffness: 200, damping: 18 });
  const ry = useSpring(useMotionValue(0), { stiffness: 200, damping: 18 });
  const move = (e: React.MouseEvent) => {
    const el = ref.current!,
      b = el.getBoundingClientRect(),
      px = (e.clientX - b.left) / b.width,
      py = (e.clientY - b.top) / b.height;
    ry.set((px - 0.5) * 16);
    rx.set(-(py - 0.5) * 16);
    el.style.setProperty("--gx", `${px * 100}%`);
    el.style.setProperty("--gy", `${py * 100}%`);
  };
  const leave = () => {
    rx.set(0);
    ry.set(0);
  };
  const [rip, setRip] = useState<{ id: number; x: number; y: number }[]>([]);
  const press = (e: React.PointerEvent) => {
    const b = ref.current!.getBoundingClientRect(),
      id = Date.now();
    setRip((r) => [...r, { id, x: e.clientX - b.left, y: e.clientY - b.top }]);
    setTimeout(() => setRip((r) => r.filter((z) => z.id !== id)), 650);
    try {
      navigator.vibrate?.(8);
    } catch {}
  };
  return (
    <motion.li variants={item}>
      <motion.div
        style={{ rotateX: rx, rotateY: ry, transformPerspective: 900 }}
        whileHover={{ y: -8, scale: 1.03 }}
        whileTap={{ scale: 0.95 }}
        transition={{ type: "spring", stiffness: 300, damping: 18 }}
      >
        <Link
          ref={ref}
          href={x.href}
          target={x.external ? "_blank" : undefined}
          rel={x.external ? "noopener noreferrer" : undefined}
          onMouseMove={move}
          onMouseLeave={leave}
          onPointerDown={press}
          className={`home-tile group relative flex h-36 flex-col justify-between overflow-hidden rounded-[22px] p-4 shadow-sm transition-shadow hover:shadow-[0_18px_40px_rgba(14,58,91,.28)] lg:h-44 ${x.c}`}
        >
          <span className="tile-glare pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
          <span className="tile-number relative z-10">{String(n).padStart(2, "0")}</span>
          <TileArt kind={x.kind} />
          {rip.map((r) => (
            <span
              key={r.id}
              className="ripple"
              style={{
                left: r.x - 120,
                top: r.y - 120,
                width: 240,
                height: 240,
              }}
            />
          ))}
          <FontAwesomeIcon
            icon={faArrowRight}
            className="absolute bottom-4 right-4 -translate-x-3 opacity-0 transition duration-300 group-hover:translate-x-0 group-hover:opacity-80"
          />
          {x.kind === "arkadaslar" && <UnreadBadge className="absolute left-4 top-9 z-10 ring-2 ring-sky" />}
          <span>
            <b className="block font-display text-lg leading-tight">{x.t}</b>
            <span className="text-[13px] opacity-75">{x.d}</span>
          </span>
        </Link>
      </motion.div>
    </motion.li>
  );
}

const tileByHref = (href: string) => tiles.find((t) => t.href === href)!;

/** Keşfet kutularını kategorilere ayıran, animasyonlu açılır/kapanır menü. */
function CategoryMenu() {
  const { open, toggle, setAll } = useOpenCats("bigova-cats-home", ["city"]);
  const { total } = useUnread();
  const allOpen = CATEGORIES.every((c) => open.has(c.id));
  return (
    <section aria-label="Kategoriler" className="mt-6 px-5">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="font-display text-xl font-extrabold">Neye bakıyorsun?</h2>
        <button
          type="button"
          onClick={() => setAll(allOpen ? [] : CATEGORIES.map((c) => c.id))}
          className="rounded-full bg-card px-3 py-1.5 text-xs font-extrabold shadow-sm"
        >
          {allOpen ? "Hepsini kapat" : "Hepsini aç"}
        </button>
      </div>
      <div className="grid gap-3">
        {CATEGORIES.map((cat, ci) => {
          const items = cat.hrefs.map(tileByHref);
          const isOpen = open.has(cat.id);
          const panel = `cat-panel-${cat.id}`;
          return (
            <motion.div
              key={cat.id}
              initial={{ opacity: 0, y: 22 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.06 * ci, type: "spring", stiffness: 260, damping: 24 }}
              className="home-cat overflow-hidden rounded-[26px] bg-card shadow-sm"
              style={{ ["--cat" as string]: `var(--${cat.tone})` }}
            >
              <button
                type="button"
                aria-expanded={isOpen}
                aria-controls={panel}
                onClick={() => toggle(cat.id)}
                className="cat-head relative flex w-full items-center gap-3 overflow-hidden p-4 text-left"
              >
                <span className="cat-wave" aria-hidden="true">
                  <svg viewBox="0 0 1200 60" preserveAspectRatio="none" className="wave-a absolute bottom-0 left-0 h-full w-[200%]">
                    <path d="M0 30 Q150 0 300 30 T600 30 T900 30 T1200 30 V60 H0Z" style={{ fill: "rgb(var(--cat) / .22)" }} />
                  </svg>
                  <svg viewBox="0 0 1200 60" preserveAspectRatio="none" className="wave-b absolute bottom-0 left-0 h-[85%] w-[200%]">
                    <path d="M0 30 Q150 0 300 30 T600 30 T900 30 T1200 30 V60 H0Z" style={{ fill: "rgb(var(--cat) / .18)" }} />
                  </svg>
                </span>
                <span className={`relative grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-xl ${TONE_BG[cat.tone]}`}>
                  <FontAwesomeIcon icon={cat.icon} />
                </span>
                <span className="relative min-w-0 flex-1 leading-tight">
                  <b className="block font-display text-lg">{cat.label}</b>
                  <span className="block truncate text-[13px] text-ink/65">{cat.blurb}</span>
                </span>
                <span className="relative flex shrink-0 items-center gap-2">
                  {cat.id === "social" && !isOpen && total > 0 && <UnreadBadge />}
                  <span className="rounded-full bg-foam px-2.5 py-1 text-xs font-extrabold">{items.length}</span>
                  <FontAwesomeIcon icon={faChevronDown} className="cat-chevron text-sm opacity-60" />
                </span>
              </button>
              <div id={panel} className="cat-body" data-open={isOpen} role="region" aria-label={cat.label}>
                <div className="cat-inner">
                  <motion.ul
                    variants={list}
                    initial="hidden"
                    animate={isOpen ? "show" : "hidden"}
                    className="grid grid-cols-2 gap-3 px-3 pb-4 pt-3 md:grid-cols-3 lg:gap-4"
                  >
                    {items.map((x, i) => (
                      <Tile key={x.t} x={x} n={i + 1} />
                    ))}
                  </motion.ul>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}

function UnreadCard() {
  const { total, items } = useUnread();
  if (total <= 0) return null;
  return (
    <motion.section
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      aria-label="Yeni mesajlar"
      className="mx-5 mt-4 overflow-hidden rounded-[22px] bg-card shadow-sm"
    >
      <div className="flex items-center gap-3 p-4 pb-2">
        <span className="grid h-10 w-10 place-items-center rounded-full bg-coral text-deep">
          <FontAwesomeIcon icon={faMessage} />
        </span>
        <b className="flex-1 font-display text-base">
          {total} yeni mesajın var
        </b>
        <Link href="/arkadaslar" className="text-sm font-extrabold text-sea">
          Tümü
        </Link>
      </div>
      <ul className="px-2 pb-2">
        {items.slice(0, 3).map((i) => (
          <li key={i.friend_id}>
            <Link href={`/arkadaslar/${i.friend_id}`} className="flex items-center gap-3 rounded-2xl px-2 py-2 hover:bg-foam">
              <span className="min-w-0 flex-1 leading-tight">
                <b className="block truncate">{i.name || "Arkadaşın"}</b>
                <span className="block truncate text-sm text-ink/65">{i.last_body}</span>
              </span>
              <span className="unread-badge">{i.unread}</span>
            </Link>
          </li>
        ))}
      </ul>
    </motion.section>
  );
}

export default function Home() {
  const router = useRouter();
  const { user, name } = useUser();
  const { scrollY } = useScroll();
  const hy = useTransform(scrollY, [0, 300], [0, -18]);
  const [q, setQ] = useState("");
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI((n) => (n + 1) % words.length), 2200);
    return () => clearInterval(t);
  }, []);
  const go = (e: React.FormEvent) => {
    e.preventDefault();
    router.push(
      q.trim()
        ? `/isletmeler?q=${encodeURIComponent(q.trim())}`
        : "/isletmeler",
    );
  };
  return (
    <main>
      <header className="hero-cq relative overflow-hidden rounded-b-[36px] bg-gradient-to-b from-sea to-sea2 px-5 pb-16 pt-[max(4rem,calc(env(safe-area-inset-top)+3.25rem))] text-white lg:pt-6">
        <span className="cloud left-0 top-8 h-5 w-24" />
        <span className="cloud left-0 top-20 h-4 w-16 [animation-delay:-16s]" />
        <div className="hero-row">
          <div className="hero-slot">
            <Weather />
          </div>
          <motion.div style={{ y: hy }} className="hero-greet relative z-10">
            <motion.p
              initial={{ opacity: 0, x: -16 }}
              animate={{ opacity: 1, x: 0 }}
              className="text-sm text-sky"
            >
              Merhaba{user && name ? `, ${name}` : ""}{" "}
              <FontAwesomeIcon
                icon={faHand}
                className="inline-block origin-[70%_70%] animate-[wig_2.4s_ease_infinite]"
              />
            </motion.p>
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1, duration: 0.6 }}
              className="mt-1 font-display text-[28px] font-extrabold leading-tight"
            >
              Bugün Biga'da
              <br />
              ne yapıyoruz?
            </motion.h1>
          </motion.div>
        </div>
      </header>

      <motion.form
        onSubmit={go}
        whileHover={{ scale: 1.01 }}
        whileFocus={{ scale: 1.02 }}
        className="relative z-10 mx-5 -mt-7 flex items-center gap-3 rounded-full bg-card px-5 py-4 text-ink shadow-[0_10px_30px_rgba(14,58,91,.16)] transition-shadow focus-within:shadow-[0_14px_40px_rgba(44,196,181,.45)] focus-within:ring-2 focus-within:ring-tide"
      >
        <FontAwesomeIcon icon={faMagnifyingGlass} className="text-ink/60" />
        <div className="relative flex-1">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            aria-label="İşletme ara"
            className="w-full bg-transparent !outline-none"
          />
          {!q && (
            <span className="pointer-events-none absolute inset-0 flex items-center gap-1 text-ink/60">
              <AnimatePresence mode="wait">
                <motion.b
                  key={i}
                  initial={{ y: 12, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: -12, opacity: 0 }}
                  transition={{ duration: 0.25 }}
                  className="font-semibold"
                >
                  {words[i]}
                </motion.b>
              </AnimatePresence>{" "}
              ara…
            </span>
          )}
        </div>
        <motion.button
          whileTap={{ scale: 0.88 }}
          whileHover={{ scale: 1.1 }}
          aria-label="Ara"
          className="grid h-9 w-9 place-items-center rounded-full bg-sea text-white"
        >
          <FontAwesomeIcon icon={faArrowRight} />
        </motion.button>
      </motion.form>

      <UnreadCard />
      <PushControl variant="banner" />
      <EventAnnouncement />

      <CategoryMenu />

      {user === null && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          whileHover={{ y: -4 }}
        >
          <Link
            href="/giris"
            className="group mx-5 mt-5 flex items-center gap-3 rounded-[26px] bg-card p-4 shadow-sm transition-shadow hover:shadow-lg"
          >
            <Mascot size={44} />
            <span className="flex-1 text-sm">
              <b className="block font-display text-base">
                Giriş yap veya kayıt ol
              </b>
              Notlar, arkadaşlar ve mesajlar seni bekliyor.
            </span>
            <FontAwesomeIcon
              icon={faArrowRight}
              className="mr-2 transition group-hover:translate-x-1.5"
            />
          </Link>
        </motion.div>
      )}

      <StudentHome />
    </main>
  );
}
