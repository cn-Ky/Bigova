import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";
export async function middleware(req: NextRequest) {
  let res = NextResponse.next({ request: req });
  if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) return res; // env eksikse siteyi çökertme
  const s = createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
    cookies: {
      getAll: () => req.cookies.getAll(),
      setAll: (list) => {
        list.forEach(({ name, value }) => req.cookies.set(name, value));
        res = NextResponse.next({ request: req });
        list.forEach(({ name, value, options }) => res.cookies.set(name, value, options));
      },
    },
  });
  try { await s.auth.getUser(); } catch {} // oturumu yeniler
  return res;
}
export const config = { matcher: ["/((?!_next/static|_next/image|favicon.ico|api/health|sw\\.js|api/push/send|api/weather|api/map-places|manifest.webmanifest|.*\\.(?:png|jpg|jpeg|ico|svg|webp)$).*)"] };
