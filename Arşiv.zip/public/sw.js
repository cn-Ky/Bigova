/* Bigova service worker: yalnızca anlık bildirimler için (önbellek tutmaz). */
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (event) => event.waitUntil(self.clients.claim()));

self.addEventListener("push", (event) => {
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch {
    data = { title: "Bigova", body: event.data ? event.data.text() : "" };
  }
  const title = data.title || "Bigova";
  event.waitUntil(
    (async () => {
      // Uygulama açık ve görünürse uygulama içi bildirim zaten gösteriliyor; telefonu titretme.
      const wins = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
      if (wins.some((c) => c.visibilityState === "visible" && c.focused)) return;
      await self.registration.showNotification(title, {
        body: data.body || "",
        icon: "/icon-192.png",
        badge: "/icon-192.png",
        tag: data.tag || "bigova",
        renotify: true,
        data: { url: data.url || "/arkadaslar" },
      });
    })(),
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  // Yalnızca site içi yollar açılır ("//evil.com" veya tam URL'ler yok sayılır)
  const raw = (event.notification.data && event.notification.data.url) || "/";
  const url = typeof raw === "string" && /^\/(?!\/)[\w\-./?=&%]*$/.test(raw) ? raw : "/";
  event.waitUntil(
    (async () => {
      const wins = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
      for (const c of wins) {
        if ("focus" in c) {
          await c.focus();
          if ("navigate" in c) {
            try {
              await c.navigate(url);
            } catch {}
          }
          return;
        }
      }
      await self.clients.openWindow(url);
    })(),
  );
});
